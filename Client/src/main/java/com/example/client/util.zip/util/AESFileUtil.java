package com.example.client.util;

import com.example.client.constant.CommonConst;
import org.apache.commons.codec.binary.Base64;
import org.springframework.util.Base64Utils;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.*;

/**
 * @author 言曌
 * @date 2021/1/23 9:17 下午
 */

public class AESFileUtil {

    /**
     * 加密文件
     *
     * @param key            AES key
     * @param sourceFilePath 原路径
     * @param destFilePath   目标路径
     * @throws Exception
     */
    public static void encryptFile(String key, String sourceFilePath, String destFilePath) throws Exception {
        byte[] content = getFileContent(sourceFilePath);
        String result = AESUtil.encode(new String(content, "UTF-8"), key);
        writeToFile(destFilePath, result);
    }

    /**
     * 解密文件
     *
     * @param key            AES key
     * @param sourceFilePath 原路径
     * @throws Exception
     */
    public static String decrypt(String key, String sourceFilePath) throws Exception {
        byte[] content = getFileContent(sourceFilePath);
        String result = AESUtil.decode(new String(content, "UTF-8"), key);
        return result;
    }


    public static void main(String[] args) throws Exception {
        encryptFile(CommonConst.AES_KEY, "/Users/liuyanzhao/Desktop/a.txt", "/Users/liuyanzhao/Desktop/a2.txt");
        String result = decrypt(CommonConst.AES_KEY, "/Users/liuyanzhao/Desktop/a2.txt");
        writeToFile("/Users/liuyanzhao/Desktop/a3.txt", result);

        encryptFile(CommonConst.AES_KEY, "/Users/liuyanzhao/Desktop/sea.jpeg", "/Users/liuyanzhao/Desktop/sea2.jpeg");
        String result2 = decrypt(CommonConst.AES_KEY, "/Users/liuyanzhao/Desktop/sea2.jpeg");
        writeToFile("/Users/liuyanzhao/Desktop/sea3.jpeg", result2);
    }


    /**
     * 将文件转成base64 字符串
     *
     * @param path 文件路径
     * @return *
     * @throws Exception
     */
    private static String encodeBase64File(String path) throws Exception {
        File file = new File(path);
        FileInputStream inputFile = new FileInputStream(file);
        byte[] buffer = new byte[(int) file.length()];
        inputFile.read(buffer);
        inputFile.close();
        return new BASE64Encoder().encode(buffer);
    }

    /**
     * 将base64字符解码保存文件
     *
     * @param base64Code
     * @param targetPath
     * @throws Exception
     */
    private static void decoderBase64File(String base64Code, String targetPath, String catalogue)
            throws Exception {
        File file = new File(catalogue);
        if (file.exists() == false) {
            file.mkdirs();
        }
        byte[] buffer = new BASE64Decoder().decodeBuffer(base64Code);
        FileOutputStream out = new FileOutputStream(targetPath);
        out.write(buffer);
        out.close();
    }

    /**
     * 往文件中写入内容
     *
     * @param outputFilePath 输出文件路径
     * @param content
     */
    private static void writeToFile(String outputFilePath, String content) throws IOException {
        File file = new File(outputFilePath);
        if (!file.exists()) {
            file.createNewFile();
        }
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * 从文件读取内容
     *
     * @param filePath
     * @return
     * @throws IOException
     */
    public static byte[] getFileContent(String filePath) throws IOException {
        File file = new File(filePath);
        long fileSize = file.length();
        if (fileSize > Integer.MAX_VALUE) {
            System.out.println("file too big...");
            return null;
        }
        FileInputStream fi = new FileInputStream(file);
        byte[] buffer = new byte[(int) fileSize];
        int offset = 0;
        int numRead = 0;
        while (offset < buffer.length
                && (numRead = fi.read(buffer, offset, buffer.length - offset)) >= 0) {
            offset += numRead;
        }
        // 确保所有数据均被读取
        if (offset != buffer.length) {
            throw new IOException("Could not completely read file "
                    + file.getName());
        }
        fi.close();
        return buffer;
    }

}
